export const i18n = {
    locales: ['en', 'zh'],
    defaultLocale: 'en',
};